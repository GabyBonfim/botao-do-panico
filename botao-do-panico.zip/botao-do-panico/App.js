import React, { useState, useEffect } from 'react';
import { View, TouchableOpacity, Image, Text, StyleSheet, Alert } from 'react-native';

export default function App() {
  // Estado que controla a visibilidade do botão
  const [showSecondButton, setShowSecondButton] = useState(false);


  // Função para o segundo botão (quando pressionado)
  const handlePressGame = () => {
    Alert.alert('Seguindo para o jogo!', 'Você pressionou "Seguir para o jogo".');
  };

  // useEffect mostra o segundo botão após 2 segundos
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSecondButton(true); // Exibe o botão após 2 segundos
    }, 2000);

    // Limpa o temporizador se o componente for desmontado
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.button}
      >
        <Image
          source={require('./assets/logogame.png')}
          style={styles.image}
        />
      </TouchableOpacity>

      {/* Condicional para exibir o segundo botão após 2 segundos */}
      {showSecondButton && (
        <TouchableOpacity
          style={styles.secondButton}
          onPress={handlePressGame}
        >
          <Text style={styles.buttonText}>Seguir para o jogo</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// Estilos
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f0d6c8',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  image: {
    width: 300,
    height: 300,
  },
  secondButton: {
    marginTop: 6, // Espaço entre a imagem e o botão
    backgroundColor: '#de482c',
    padding: 20,
    borderRadius: 50,
  },
  buttonText: {
    fontSize: 14,
    color: '#fff',
  },
});
